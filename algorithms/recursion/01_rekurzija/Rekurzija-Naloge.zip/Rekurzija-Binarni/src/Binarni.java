
public class Binarni {

	public static void izpisiBinarno(int n)
	{
		//TODO
		// napisite rekurzivno funkcijo, ki vhodno stevilo "n" 
		// izpise v binarni obliki
		//
		// potrebujete ustavitveni pogoj
		// in splosno rekurzivno pravilo
	}
	
	public static void main(String[] args) {
		for (int i = 0; i < 20; i++)
		{
			System.out.print("Zapis stevila " + i + " v binarni obliki je: ");
			izpisiBinarno(i);
			System.out.println();
		}
	}

}
