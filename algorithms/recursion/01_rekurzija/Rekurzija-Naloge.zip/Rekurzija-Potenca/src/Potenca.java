import java.util.*;

public class Potenca {

	// Rekurzivna funkcija, ki preveri, 
	// ali je stevilo "a" potenca stevila "b"
	public static boolean jePotenca(int a, int b)
	{
		// napisite rekurzivno funkcijo
		//
		// potrebujete ustavitveni pogoj
		// in splosno rekurzivno pravilo
		return false;
	}
	
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		in.useLocale(Locale.US);
		 
        int a, b;
        System.out.print("Vnesi stevilo a: ");
        a = in.nextInt();
        System.out.print("Vnesi stevilo b: ");
        b = in.nextInt();
        
        in.close();
            
        if (jePotenca(a,b))
            System.out.println("Stevilo " + a + " je potenca stevila " + b);
        else
            System.out.println("Stevilo " + a + " ni potenca stevila " + b); 

	}
}
